Just some notes on how to use this.

SHORT Description :
soapui > tcpmon > our request service > our client tcpmon > DERMSMaster (and back again)

First, start tcpmon with startup.bat/sh, whichever...

This is a great tool for when we are testing our direct or request services. Following
are basic instructions on how to set it up for (example) requestDERGetStatuses

1. startup.bat
2. click Admin

Our setup for doing a request getderstatus would be set up like this :

request service : http://localhost:8080/DERConnect/cim/request
<requestURL> : http://localhost/8181/status (for DERMSmaster)
Please note ports 8080 for our service, 8181 for DERMSmaster

3. click Admin in tcpmon and do the following :

a. Listen Port: 8079
b. Target Hostname: 127.0.0.1
c. targetPort 8080 
d. click 'Add'

Note new tab at top 'Port 8079'

4. click Admin again and do the following :

a. Listen Port : 8180
b. Target Hostname: 127.0.0.1
c. target Port : 8181
d. click 'Add'

Note new tab 'port 8180'

5. Go to both tabs and clikc 'XML' check box, makes it easier to read

6. Modify soapui for request get statuses thusly

request service : http://localhost:8079/DERConnect/cim/request
<requestURL> : http://localhost:8180/status

7. run soapui commands

Result :

You have placed TPCMON in the middle between soapui and request, and between soapui and DERMSmaster.

When you run soapui, it will send request to tcpmon on 8079, which will forward to our services on 8080. And when request sends client command to DERMSMaster, it will be intercepted on 8180 and forwarded to 8181.

You get to see every piece of SOAP data. This makes it easier to see where things went wrong.


