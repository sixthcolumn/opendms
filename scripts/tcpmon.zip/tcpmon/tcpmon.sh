java -cp ./tcpmon-1.0.jar org.apache.ws.commons.tcpmon.TCPMon $*
